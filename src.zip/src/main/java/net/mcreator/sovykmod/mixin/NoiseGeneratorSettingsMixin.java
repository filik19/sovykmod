package net.mcreator.sovykmod.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.sovykmod.init.SovykmodModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements SovykmodModBiomes.SovykmodModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> sovykmod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.sovykmod_dimensionTypeReference != null) {
			retval = SovykmodModBiomes.adaptSurfaceRule(retval, this.sovykmod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setsovykmodDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.sovykmod_dimensionTypeReference = dimensionType;
	}
}