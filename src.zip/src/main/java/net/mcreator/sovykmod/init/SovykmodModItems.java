/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sovykmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.sovykmod.SovykmodMod;

import java.util.function.Function;

public class SovykmodModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SovykmodMod.MODID);
	public static final DeferredItem<Item> SOVYKBLOCK;
	public static final DeferredItem<Item> SOVYKEN_SPAWN_EGG;
	static {
		SOVYKBLOCK = block(SovykmodModBlocks.SOVYKBLOCK);
		SOVYKEN_SPAWN_EGG = register("sovyken_spawn_egg", properties -> new SpawnEggItem(SovykmodModEntities.SOVYKEN.get(), properties));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}