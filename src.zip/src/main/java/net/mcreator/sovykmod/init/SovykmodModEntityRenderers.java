/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sovykmod.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.sovykmod.client.renderer.SovykenRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class SovykmodModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SovykmodModEntities.SOVYKEN.get(), SovykenRenderer::new);
	}
}